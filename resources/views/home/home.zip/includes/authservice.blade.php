<!DOCTYPE html>
<html lang="en-us">
<head>
@include('home/includes/header')
</head>
<body>

</body>
<footer>
  <div class="row" style="text-align:center">
    <p class="copyright text-muted">Copyright &copy; MyMathKings 2017</p>
    {{-- Created by Moffat Munene, @moffmu, moffmu@gmail.com --}}
    {{-- Copyright of the Mymathkings, subsidiary of Kings Inc. See terms and conditions   --}}
  </div>
</footer>
</html>
