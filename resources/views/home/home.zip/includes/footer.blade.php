
<hr />
<div class="container">
  <div class="row">
    <div class="col-md-4" style="text-align:left">
      <h2>Quick Links</h2>
      <ul style="list-style:none;">
        <li>
          <li class="list-inline-item animated wow fadeInUp">
            <a href="#">
              <span class="fa-stack fa-lg">
                <i class="fa fa-circle fa-stack-2x"></i>
                <i class="fa fa-caret-up fa-stack-1x fa-inverse"></i>
              </span> Top
            </a>
          </li>
        </li>
        <li class="list-inline-item animated wow fadeInUp">
          <a href="#">
            <span class="fa-stack fa-lg">
              <i class="fa fa-circle fa-stack-2x"></i>
              <i class="fa fa-wrench fa-stack-1x fa-inverse"></i>
            </span> Services
          </a>
        </li>
        <li class="list-inline-item animated wow fadeInUp">
          <a href="#">
            <span class="fa-stack fa-lg">
              <i class="fa fa-circle fa-stack-2x"></i>
              <i class="fa fa-comments fa-stack-1x fa-inverse"></i>
            </span> About
          </a>
        </li>
        <li class="list-inline-item animated wow fadeInUp">
          <a href="#">
            <span class="fa-stack fa-lg">
              <i class="fa fa-circle fa-stack-2x"></i>
              <i class="fa fa-home fa-stack-1x fa-inverse"></i>
            </span> Home
          </a>
        </li>

      </ul>
    </div>
    <div class="col-md-4" style="text-align:left">
      <h2>Social</h2>
      <ul style="list-style:none;">
        <li class="list-inline-item animated wow fadeInUp">
          <a href="https://web.facebook.com/The-kings-inc-465109913852861/"
          data-layout="button" data-action="like" data-size="large" data-show-faces="false" data-share="true">
          <span class="fa-stack fa-lg">
            <i class="fa fa-circle fa-stack-2x"></i>
            <i class="fa fa-facebook fa-stack-1x fa-inverse"></i>
          </span> Facebook
        </a>
        <script>(function(d, s, id) {
          var js, fjs = d.getElementsByTagName(s)[0];  if (d.getElementById(id)) return;
          js = d.createElement(s); js.id = id;  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.9";
          fjs.parentNode.insertBefore(js, fjs);}(document, 'script', 'facebook-jssdk'));</script>
        </li>
        <li class="list-inline-item animated wow fadeInUp">
          <a href="https://twitter.com/The_Kings_Inc" data-show-count="false">
            <span class="fa-stack fa-lg">
              <i class="fa fa-circle fa-stack-2x"></i>
              <i class="fa fa-twitter fa-stack-1x fa-inverse"></i>
            </span> Twitter
          </a>
          <script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
        </li>
        <!--li class="list-inline-item animated wow fadeInUp">
        <a href="#">
        <span class="fa-stack fa-lg">
        <i class="fa fa-circle fa-stack-2x"></i>
        <i class="fa fa-instagram fa-stack-1x fa-inverse"></i>
      </span> Instagram
    </a>
  </li>
  <li class="list-inline-item animated wow fadeInUp">
  <a href="#">
  <span class="fa-stack fa-lg">
  <i class="fa fa-circle fa-stack-2x"></i>
  <i class="fa fa-linkedin fa-stack-1x fa-inverse"></i>
</span>Linked In
</a>
</li-->
</ul>
</div>
<div class="col-md-4" style="text-align:left">
  <h2>Summary</h2>
</div>
</div>

<div class="row" style="text-align:center">
  <p class="copyright text-muted">Copyright &copy; MyMathKings 2017</p>
</div>
</div>
<script async type="text/javascript" src="{{asset('home/js/combined.js')}}"></script>
<script async src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
{{-- Created by Moffat Munene, @moffmu, moffmu@gmail.com --}}
{{-- Copyright of the Mymathkings, subsidiary of Kings Inc. See terms and conditions   --}}
