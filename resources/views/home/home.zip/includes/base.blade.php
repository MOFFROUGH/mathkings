<!DOCTYPE html>
<html lang="en-us">
<head>
@include('home/includes/header')
</head>
<body id="main-body2">
<div class="container-fluid">
  @include('home/includes/body')
  </body>
  <footer>
  @include('home/includes/footer')
  </footer>
</div>

{{-- Created by Moffat Munene, @moffmu, moffmu@gmail.com --}}
{{-- Copyright of the Mymathkings, subsidiary of Kings Inc. See terms and conditions   --}}
</html>
